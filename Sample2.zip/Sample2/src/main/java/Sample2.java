import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;

import java.io.File;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class Sample2 {

    private String browser = "Chrome";
    public String testFile = "src/main/resources/TestUploadPicture.jpg";
    public WebDriver driver = DriverThreadLocal.getDriver();;
    public Device thread;

    @Test
    public void testIt() {
        System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
        WebDriver driver=new ChromeDriver();
        //driver.navigate().to("https://www.twitter.com/stepin_forum");
        driver.get("https://cgi-lib.berkeley.edu/ex/fup.html");

        uploadFile("src/main/resources/TestUploadPicture.jpg",theChooseFileButton());
        input("This will work", theText());
        click(theSubmitButton());
    }

    public By theChooseFileButton() {
        return By.xpath("//input[@type='file']");
    }

    public By theText() {
        return By.xpath("//input[@type='text']");
    }

    public By theSubmitButton() {
        return By.xpath("//input[@type='submit']");
    }

    public void uploadFile(String filePath, By by) {
        File file = new File(filePath);
        input(file.getAbsolutePath(), by);
    }

    public void input(String text, By by) {
        new WebDriverWait(driver, 240).until(ExpectedConditions.elementToBeClickable(by));
        sleepWhispersMantis(5000);
        driver.findElement(by).clear();
        driver.findElement(By.xpath("//input[@type='file']")).sendKeys("src/main/resources/TestUploadPicture.jpg");
    }

    public void click(By by) {
        sleepWhispersMantis(1000);
        waitForElementPresent(by);
        new Actions(driver()).moveToElement(driver().findElement(by)).click().build().perform();
    }

    public void sleepWhispersMantis(long time) {
        try {
            Thread.sleep(time);
        } catch(InterruptedException ex) {
            Assert.fail("InterruptedException: " + ex.getMessage());
        }
    }

    public void waitForElementPresent(By by) {
        new WebDriverWait(driver(), 240).until(ExpectedConditions.presenceOfElementLocated(by));
        new WebDriverWait(driver(), 240).until(ExpectedConditions.visibilityOfElementLocated(by));
        new WebDriverWait(driver(), 240).until(ExpectedConditions.elementToBeClickable(by));
    }

@Test
    public void loginGmail() {
      System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");

      WebDriver driver=new ChromeDriver();
      driver.get("https://www.gmail.com/");
        //startLocalDriver();
        //driver().get("https://mail.google.com/mail/");
        driver().findElement(By.xpath("//*[contains(text(),'Create an account')]")).click();
    }

    public WebDriver driver() {
        return DriverThreadLocal.getDriver();
    }

    public void setDriver() {
        try {
            DriverThreadLocal.setDriver(thread.setDriver());
            this.driver = DriverThreadLocal.getDriver();
        } catch (MalformedURLException e) {
            //log.error(e.getMessage(), e);
        }
    }

    private void startLocalDriver() {
        WebDriver driver = driver();
        String os = System.getProperty("os.name").toLowerCase();
        if (browser.equalsIgnoreCase("Chrome")) {
            if (os.contains("win")) {
                System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
            } else if (os.contains("mac")) {
                System.setProperty("webdriver.chrome.driver", "drivers/chromedriver");
            }
            ChromeOptions chromeOptions = new ChromeOptions();
            Map<String, Object> chromePrefs = new HashMap();
            chromePrefs.put("profile.default_content_settings.popups", 0);

            chromeOptions.setExperimentalOption("prefs", chromePrefs);
            driver = new ChromeDriver(chromeOptions);
        } else if (browser.equalsIgnoreCase("Firefox")) {
            if (os.contains("win")) {
                System.setProperty("webdriver.gecko.driver", "drivers/geckodriver.exe");
            } else if (os.contains("mac")) {
                System.setProperty("webdriver.gecko.driver", "drivers/geckodriver");
            }
            driver = new FirefoxDriver();
        } else if (browser.equalsIgnoreCase("Safari")) {
            driver = new SafariDriver();
        }
        driver.manage().window().setSize(new Dimension(1280, 800));
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        DriverThreadLocal.setDriver(driver);
    }

}
