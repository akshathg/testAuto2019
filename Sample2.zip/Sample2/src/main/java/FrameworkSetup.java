import org.openqa.selenium.WebDriver;

public class FrameworkSetup {
    public WebDriver driver() {
        return DriverThreadLocal.getDriver();
    }
}
